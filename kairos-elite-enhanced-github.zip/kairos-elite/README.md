# Kairos Elite — Digital Agency Website

A premium, light-themed, responsive React + Vite website with a procedural 3D Three.js AI assistant, agency service showcase, founder section, interactive business-planning tools, a 21-point growth blueprint, customer-journey framework, expandable FAQs, and an enquiry form. The original homepage, Three.js assistant, service cards, founder block and calculators are retained; the new experience is added as a separate component and additive CSS layer.

## Run locally

1. Install Node.js (LTS recommended).
2. Open this folder in VS Code.
3. Run `npm install`.
4. Run `npm run dev` and open the local URL shown in the terminal.
5. Run `npm run build` to create the production site in `dist/`.

## Publish with GitHub Pages

1. Create a new GitHub repository and upload the contents of this folder.
2. In the repository, open **Settings → Pages**.
3. Choose **GitHub Actions** as the deployment source.
4. Add the workflow below as `.github/workflows/deploy.yml`.

```yaml
name: Deploy Vite site to GitHub Pages
on:
  push:
    branches: [main]
  workflow_dispatch:
permissions:
  contents: read
  pages: write
  id-token: write
concurrency:
  group: pages
  cancel-in-progress: true
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 22
          cache: npm
      - run: npm install
      - run: npm run build
      - uses: actions/upload-pages-artifact@v3
        with:
          path: dist
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    steps:
      - id: deployment
        uses: actions/deploy-pages@v4
```

## Before going live

- Confirm that **₹13.64 lakh value served** and **12 real clients served** are accurate and approved for public display. The site labels the first metric as value served, not revenue or profit.
- Replace `hello@kairoselite.in` in `src/main.jsx` with the agency's real enquiry email. The current form opens the visitor's email app; it does not store submissions.
- Add real portfolio work, client testimonials, social links, privacy policy and terms only after obtaining permission and verifying the details.
- The assistant is a front-end guided assistant with predefined responses. It is not connected to a live AI model or backend. Connect a secure server-side AI API if live AI responses are required; never expose private API keys in frontend code.
- The campaign and automation calculators are illustrative planning tools, not guarantees or professional financial advice.

## Added agency experience layer
- Customer journey framework: discovery → conversion → follow-up.
- Interactive 21-point digital growth self-review with a live score.
- Agency positioning cards explaining the connected service approach.
- Expandable FAQs covering scope, outcomes and project kickoff.
- Additional navigation anchors for Our approach, Growth blueprint and FAQ.
- `vite.config.js` uses relative asset paths so the build works on GitHub Pages project URLs.

The new sections are purpose-built for Kairos Elite. They take inspiration from the reference site’s use of proof, guided education, structured checklists, process explanations and FAQs, without copying its branding, wording or industry-specific content.

## Tech
React, Vite, Three.js, Lucide React, CSS. Google Fonts are loaded remotely; provide local font files if you need fully self-hosted assets.
